﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace AplikacijaBiblioteka
{
    public partial class PosudbaKnjige : Form
    {
        static List<PosudbaKnjige> ListaPosudbaKnjiga = new List<PosudbaKnjige>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "Posudba.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);
        public PosudbaKnjige()
        {
            InitializeComponent();
        }

        private void btnUpisPosudba_Click(object sender, EventArgs e)
        {




        }
    }
}
