﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;
using System.Collections;

namespace AplikacijaBiblioteka
{
    public partial class Form1 : Form
    {
        static List<Korisnici> ListaKorisnika = new List<Korisnici>();
        static string pathdocuments = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        static string xmlfile = "Korisnici.xml";
        static string path = Path.Combine(pathdocuments, xmlfile);



        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Korisnici UpisKorisnika = new Korisnici(Convert.ToInt32(txtBxId.Text), txtBxIme.Text, txtBxPrezime.Text);
            ListaKorisnika.Add(UpisKorisnika);
            DialogResult dialogResult = MessageBox.Show("Želite li napraviti još jedan upis?", "Upis", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                try
                {
                    var Korisnici = XDocument.Load(path);
                    foreach (Korisnici korisnik in ListaKorisnika)
                    {
                        var Korisnik = new XElement("Korisnik",
                            new XElement("ID", korisnik.ID1),
                            new XElement("Ime", korisnik.Ime1),
                            new XElement("Prezime", korisnik.Prezime1));
                        Korisnici.Root.Add(Korisnik);

                    }
                    Korisnici.Save(path);
                }
                catch (Exception ex)
                {
                    var Korisnici = new XDocument();
                    Korisnici.Add(new XElement("Korisnici"));
                    foreach (Korisnici korisnik in ListaKorisnika)
                    {
                        var Korisnik = new XElement("Korisnik",
                        new XElement("ID", korisnik.ID1),
                        new XElement("Ime", korisnik.Ime1),
                        new XElement("Prezime", korisnik.Prezime1));
                        Korisnici.Root.Add(Korisnik);
                    }

                    Korisnici.Save(path);

                }
                ListaKorisnika.Clear();
                this.Close();
            }
            txtBxId.Text = "";
            txtBxIme.Text = "";
            txtBxPrezime.Text = "";
        }
    }
}

                    



                            
                            
                            
                            
      

    

